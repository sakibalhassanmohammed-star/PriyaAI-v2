package com.priya.ai.live

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class ChatLine(val fromUser: Boolean, val text: String, val final: Boolean)

/** Shared live state between ListeningService and the UI. */
object PriyaBus {
    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running.asStateFlow()

    private val _state = MutableStateFlow(LiveState.IDLE)
    val state: StateFlow<LiveState> = _state.asStateFlow()

    private val _detail = MutableStateFlow("")
    val detail: StateFlow<String> = _detail.asStateFlow()

    private val _speaking = MutableStateFlow(false)
    val speaking: StateFlow<Boolean> = _speaking.asStateFlow()

    /** 0..1 loudness for the orb animation. */
    private val _level = MutableStateFlow(0f)
    val level: StateFlow<Float> = _level.asStateFlow()

    private val _tool = MutableStateFlow("")
    val tool: StateFlow<String> = _tool.asStateFlow()

    private val _chat = MutableStateFlow<List<ChatLine>>(emptyList())
    val chat: StateFlow<List<ChatLine>> = _chat.asStateFlow()

    fun setRunning(v: Boolean) { _running.value = v; if (!v) { _speaking.value = false; _level.value = 0f } }
    fun setState(s: LiveState, detail: String = "") { _state.value = s; _detail.value = detail }
    fun setSpeaking(v: Boolean) { _speaking.value = v }
    fun setLevel(v: Float) { _level.value = v.coerceIn(0f, 1f) }
    fun setTool(name: String) { _tool.value = name }

    fun transcript(fromUser: Boolean, text: String, final: Boolean) {
        val list = _chat.value.toMutableList()
        val last = list.lastOrNull()
        if (last != null && last.fromUser == fromUser && !last.final) {
            list[list.size - 1] = ChatLine(fromUser, text, final)
        } else {
            list.add(ChatLine(fromUser, text, final))
        }
        _chat.value = if (list.size > 100) list.takeLast(100) else list
    }

    fun clearChat() { _chat.value = emptyList() }
}
