@file:OptIn(ExperimentalMaterial3Api::class)

package com.priya.ai.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.priya.ai.data.UiStyle
import kotlinx.coroutines.launch

/** Page body shared by all three styles. Only the Talk page differs per style. */
@Composable
fun MenuContent(app: AppCtx, item: MenuItem, style: UiStyle) {
    when (item) {
        MenuItem.TALK -> if (style == UiStyle.ORB) OrbTalk(app) else ChatTalk(app)
        MenuItem.MEMORY -> MemoryScreen(app)
        MenuItem.PERMISSIONS -> PermissionsScreen(app)
        MenuItem.API -> ApiScreen(app)
        MenuItem.SETTINGS -> SettingsScreen(app)
        MenuItem.ABOUT -> AboutScreen(app)
    }
}

// ======================= STYLE 1: ORB + bottom menu bar =======================

@Composable
fun OrbShell(app: AppCtx, current: MenuItem?, onSelect: (MenuItem?) -> Unit) {
    val page = current ?: MenuItem.TALK
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                MenuItem.values().forEach { m ->
                    NavigationBarItem(
                        selected = m == page,
                        onClick = { onSelect(m) },
                        icon = { Icon(m.icon, contentDescription = m.title) },
                        label = { Text(m.short) },
                        alwaysShowLabel = false
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) { MenuContent(app, page, UiStyle.ORB) }
    }
}

// ======================= STYLE 2: CHAT + side drawer menu =======================

@Composable
fun ChatShell(app: AppCtx, current: MenuItem?, onSelect: (MenuItem?) -> Unit) {
    val page = current ?: MenuItem.TALK
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet {
                Text(
                    "Priya AI",
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(24.dp)
                )
                MenuItem.values().forEach { m ->
                    NavigationDrawerItem(
                        label = { Text(m.title) },
                        icon = { Icon(m.icon, contentDescription = null) },
                        selected = m == page,
                        onClick = { onSelect(m); scope.launch { drawer.close() } },
                        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                    )
                }
            }
        }
    ) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopAppBar(
                    title = { Text(page.title) },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawer.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Menu")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface,
                        navigationIconContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) { MenuContent(app, page, UiStyle.CHAT) }
        }
    }
}

// ======================= STYLE 3: CARDS home =======================

@Composable
fun CardsShell(app: AppCtx, current: MenuItem?, onSelect: (MenuItem?) -> Unit) {
    BackHandler(enabled = current != null) { onSelect(null) }
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(current?.title ?: "Priya AI") },
                navigationIcon = {
                    if (current != null) {
                        IconButton(onClick = { onSelect(null) }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Wapas")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground,
                    navigationIconContentColor = MaterialTheme.colorScheme.onBackground
                )
            )
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (current == null) CardsHome(app) { onSelect(it) }
            else MenuContent(app, current, UiStyle.CARDS)
        }
    }
}
