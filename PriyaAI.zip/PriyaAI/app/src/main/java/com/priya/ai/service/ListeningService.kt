package com.priya.ai.service

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.priya.ai.MainActivity
import com.priya.ai.data.MemoryStore
import com.priya.ai.data.Prefs
import com.priya.ai.live.GeminiLiveClient
import com.priya.ai.live.LiveListener
import com.priya.ai.live.LiveState
import com.priya.ai.live.PriyaBus
import java.util.concurrent.LinkedBlockingQueue
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Foreground service that keeps Priya listening in the background.
 *
 * Audio is only streamed to Gemini while someone is speaking (small local voice gate),
 * which keeps battery and data use low. Gemini's own VAD handles turn-taking.
 */
class ListeningService : Service() {

    private lateinit var prefs: Prefs
    private lateinit var memory: MemoryStore
    private var client: GeminiLiveClient? = null

    private var record: AudioRecord? = null
    private var track: AudioTrack? = null
    private var micThread: Thread? = null
    private var playThread: Thread? = null
    private var aec: AcousticEchoCanceler? = null
    private var ns: NoiseSuppressor? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var audioManager: AudioManager? = null
    private var oldAudioMode = AudioManager.MODE_NORMAL

    @Volatile private var running = false
    @Volatile private var playEndAt = 0L
    private val playQueue = LinkedBlockingQueue<ByteArray>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        memory = MemoryStore.get(this)
        instance = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopEverything()
            stopSelf()
            return START_NOT_STICKY
        }
        if (running) return START_STICKY

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            PriyaBus.setState(LiveState.ERROR, "Microphone permission nahi mili.")
            stopSelf()
            return START_NOT_STICKY
        }

        startAsForeground()
        running = true
        PriyaBus.setRunning(true)
        acquireWakeLock()
        setupAudioRouting()

        client = GeminiLiveClient(this, prefs, memory, liveListener).also { it.connect() }
        startPlayback()
        startMic()
        return START_STICKY
    }

    // ---------- Foreground notification ----------

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Priya sun rahi hai", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ListeningService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Priya AI")
            .setContentText("Priya sun rahi hai")
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, "Band karo", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "PriyaAI:listen").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    @Suppress("DEPRECATION")
    private fun setupAudioRouting() {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audioManager = am
        oldAudioMode = am.mode
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        am.isSpeakerphoneOn = true
    }

    // ---------- Microphone ----------

    private fun startMic() {
        val minBuf = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val chunk = 1280 // 40 ms
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION, 16000,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minBuf, chunk * 8)
            )
        } catch (e: SecurityException) {
            PriyaBus.setState(LiveState.ERROR, "Microphone use nahi kar sakte.")
            return
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            PriyaBus.setState(LiveState.ERROR, "Microphone start nahi hua.")
            return
        }
        if (AcousticEchoCanceler.isAvailable()) aec = AcousticEchoCanceler.create(rec.audioSessionId)?.also { it.enabled = true }
        if (NoiseSuppressor.isAvailable()) ns = NoiseSuppressor.create(rec.audioSessionId)?.also { it.enabled = true }
        record = rec
        rec.startRecording()

        micThread = Thread({
            val buf = ByteArray(chunk)
            val preRoll = ArrayDeque<ByteArray>()
            var gateOpenUntil = 0L
            var wasOpen = false
            while (running) {
                var read = 0
                while (read < chunk && running) {
                    val n = rec.read(buf, read, chunk - read)
                    if (n <= 0) break
                    read += n
                }
                if (read < chunk) continue
                val level = rms(buf)
                PriyaBus.setLevel(level / 6000f)

                val now = System.currentTimeMillis()
                // While Priya talks, only a clearly louder voice can interrupt her.
                val threshold = if (now < playEndAt) LOUD_THRESHOLD else QUIET_THRESHOLD
                val c = client
                if (c == null || !c.isReady) { preRoll.clear(); continue }

                if (level > threshold) {
                    if (!wasOpen) {
                        preRoll.forEach { c.sendAudio(it) }
                        preRoll.clear()
                        wasOpen = true
                    }
                    gateOpenUntil = now + HANGOVER_MS
                    c.sendAudio(buf.copyOf())
                } else if (now < gateOpenUntil) {
                    c.sendAudio(buf.copyOf())
                } else {
                    if (wasOpen) {
                        c.sendAudioStreamEnd()
                        wasOpen = false
                    }
                    preRoll.addLast(buf.copyOf())
                    if (preRoll.size > 6) preRoll.removeFirst()
                }
            }
        }, "priya-mic").also { it.start() }
    }

    private fun rms(b: ByteArray): Float {
        var sum = 0.0
        var i = 0
        val n = b.size / 2
        while (i < b.size - 1) {
            val s = ((b[i + 1].toInt() shl 8) or (b[i].toInt() and 0xFF)).toShort().toInt()
            sum += s.toDouble() * s
            i += 2
        }
        return sqrt(sum / n).toFloat()
    }

    // ---------- Playback ----------

    private fun startPlayback() {
        val minBuf = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(24000)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build()
            )
            .setBufferSizeInBytes(max(minBuf, 24000 * 2))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track = t
        t.play()
        playThread = Thread({
            while (running) {
                val data = try { playQueue.poll(200, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (e: InterruptedException) { null }
                if (data != null) {
                    t.write(data, 0, data.size)
                    PriyaBus.setLevel(rms(data) / 9000f)
                }
                val speaking = System.currentTimeMillis() < playEndAt
                if (PriyaBus.speaking.value != speaking) PriyaBus.setSpeaking(speaking)
            }
        }, "priya-play").also { it.start() }
    }

    private fun enqueueAudio(pcm: ByteArray) {
        val now = System.currentTimeMillis()
        val durationMs = pcm.size / 48L // 24000 samples/s * 2 bytes
        playEndAt = max(playEndAt, now) + durationMs
        playQueue.offer(pcm)
        PriyaBus.setSpeaking(true)
    }

    private fun clearPlayback() {
        playQueue.clear()
        playEndAt = 0L
        track?.let {
            try { it.pause(); it.flush(); it.play() } catch (_: IllegalStateException) {}
        }
        PriyaBus.setSpeaking(false)
    }

    // ---------- Gemini callbacks ----------

    private val liveListener = object : LiveListener {
        override fun onState(state: LiveState, detail: String) = PriyaBus.setState(state, detail)
        override fun onAudio(pcm24k: ByteArray) = enqueueAudio(pcm24k)
        override fun onInterrupted() = clearPlayback()
        override fun onTranscript(fromUser: Boolean, text: String, final: Boolean) =
            PriyaBus.transcript(fromUser, text, final)
        override fun onToolActivity(name: String) = PriyaBus.setTool(name)
    }

    fun sendText(text: String) {
        client?.sendText(text)
        PriyaBus.transcript(true, text, true)
    }

    // ---------- Shutdown ----------

    @Suppress("DEPRECATION")
    private fun stopEverything() {
        running = false
        client?.disconnect()
        client = null
        try { micThread?.join(300) } catch (_: InterruptedException) {}
        try { record?.stop() } catch (_: IllegalStateException) {}
        record?.release(); record = null
        aec?.release(); aec = null
        ns?.release(); ns = null
        try { track?.stop() } catch (_: IllegalStateException) {}
        track?.release(); track = null
        playQueue.clear()
        audioManager?.let {
            it.mode = oldAudioMode
            it.isSpeakerphoneOn = false
        }
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        PriyaBus.setRunning(false)
        PriyaBus.setState(LiveState.IDLE)
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    override fun onDestroy() {
        if (running) stopEverything()
        if (instance === this) instance = null
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL_ID = "priya_listening"
        private const val NOTIF_ID = 7
        private const val ACTION_STOP = "com.priya.ai.STOP"

        // Mic loudness (RMS of 16-bit samples) that opens the voice gate.
        private const val QUIET_THRESHOLD = 700f
        private const val LOUD_THRESHOLD = 2600f
        private const val HANGOVER_MS = 1200L

        @Volatile var instance: ListeningService? = null

        fun start(context: Context) {
            ContextCompat.startForegroundService(context, Intent(context, ListeningService::class.java))
        }

        fun stop(context: Context) {
            context.startService(Intent(context, ListeningService::class.java).setAction(ACTION_STOP))
        }
    }
}
