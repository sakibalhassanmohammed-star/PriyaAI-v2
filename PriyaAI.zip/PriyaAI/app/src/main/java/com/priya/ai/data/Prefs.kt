package com.priya.ai.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

enum class UiStyle(val label: String) {
    ORB("Style 1 - Orb"),
    CHAT("Style 2 - Chat"),
    CARDS("Style 3 - Cards")
}

/** Settings. The Gemini API key is stored encrypted on the device. */
class Prefs(context: Context) {

    private val plain: SharedPreferences =
        context.getSharedPreferences("priya_settings", Context.MODE_PRIVATE)

    private val secure: SharedPreferences = try {
        val key = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            context, "priya_secure", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        // Fallback if keystore is unavailable on a device.
        context.getSharedPreferences("priya_secure_fallback", Context.MODE_PRIVATE)
    }

    var apiKey: String
        get() = secure.getString("gemini_api_key", "") ?: ""
        set(v) { secure.edit().putString("gemini_api_key", v.trim()).apply() }

    var model: String
        get() = plain.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(v) { plain.edit().putString("model", v.trim().ifEmpty { DEFAULT_MODEL }).apply() }

    var voice: String
        get() = plain.getString("voice", "Kore") ?: "Kore"
        set(v) { plain.edit().putString("voice", v).apply() }

    var uiStyle: UiStyle
        get() = runCatching { UiStyle.valueOf(plain.getString("ui_style", UiStyle.ORB.name)!!) }
            .getOrDefault(UiStyle.ORB)
        set(v) { plain.edit().putString("ui_style", v.name).apply() }

    var alwaysListening: Boolean
        get() = plain.getBoolean("always_listening", false)
        set(v) { plain.edit().putBoolean("always_listening", v).apply() }

    var startOnBoot: Boolean
        get() = plain.getBoolean("start_on_boot", true)
        set(v) { plain.edit().putBoolean("start_on_boot", v).apply() }

    var userName: String
        get() = plain.getString("user_name", "") ?: ""
        set(v) { plain.edit().putString("user_name", v.trim()).apply() }

    companion object {
        const val DEFAULT_MODEL = "gemini-3.8-live"
        val FEMALE_VOICES = listOf("Kore", "Aoede", "Leda", "Zephyr", "Despina", "Sulafat")
        val MODELS = listOf("gemini-3.8-live", "gemini-3.8-live-extended-thinking", "gemini-3.1-flash-live-preview")
    }
}
