@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.priya.ai.ui

import android.Manifest
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.priya.ai.data.MemoryStore
import com.priya.ai.data.Prefs
import com.priya.ai.data.UiStyle
import com.priya.ai.live.PriyaBus
import com.priya.ai.service.ListeningService
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val GREEN = Color(0xFF4CD964)
private val AMBER = Color(0xFFFFB84D)

@Composable
private fun ScreenTitle(text: String, sub: String? = null) {
    Column(Modifier.padding(bottom = 12.dp)) {
        Text(text, style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.onBackground)
        if (sub != null) Text(sub, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ======================= PERMISSIONS =======================

private class PermRow(
    val title: String,
    val desc: String,
    val granted: Boolean,
    val auto: Boolean = false,
    val button: String = "Allow",
    val onGrant: () -> Unit = {}
)

@Composable
fun PermissionsScreen(app: AppCtx) {
    val c = app.context
    val sdk = Build.VERSION.SDK_INT
    val rows = buildList {
        // --- Ask-at-runtime permissions ---
        add(PermRow("Microphone", "Priya aapki awaaz sun sake. Iske bina voice kaam nahi karega.",
            hasPermission(c, Manifest.permission.RECORD_AUDIO)) { app.requestPermission(Manifest.permission.RECORD_AUDIO) })
        if (sdk >= 33) add(PermRow("Notifications", "Background mein 'Priya sun rahi hai' notification dikhane ke liye.",
            hasPermission(c, Manifest.permission.POST_NOTIFICATIONS)) { app.requestPermission(Manifest.permission.POST_NOTIFICATIONS) })
        add(PermRow("Contacts", "Naam bolkar kisi ko call karne ke liye.",
            hasPermission(c, Manifest.permission.READ_CONTACTS)) { app.requestPermission(Manifest.permission.READ_CONTACTS) })
        add(PermRow("Phone call", "Priya seedha call laga sake.",
            hasPermission(c, Manifest.permission.CALL_PHONE)) { app.requestPermission(Manifest.permission.CALL_PHONE) })
        if (sdk >= 31) add(PermRow("Nearby devices (Bluetooth)", "Bluetooth headset ya earbuds se baat karne ke liye.",
            hasPermission(c, Manifest.permission.BLUETOOTH_CONNECT)) { app.requestPermission(Manifest.permission.BLUETOOTH_CONNECT) })

        // --- Special access (opens Android settings) ---
        add(PermRow("Accessibility (Phone control)", "Apps kholna, screen padhna, tap, scroll aur type karna. Settings mein 'Priya AI' ko on karo.",
            isAccessibilityEnabled(c), button = "Open") { openSettings(c, Settings.ACTION_ACCESSIBILITY_SETTINGS) })
        add(PermRow("Display over other apps", "Dusre apps ke upar Priya ka status dikhane ke liye.",
            Settings.canDrawOverlays(c), button = "Open") { openSettings(c, Settings.ACTION_MANAGE_OVERLAY_PERMISSION, true) })
        add(PermRow("Battery optimization off", "Taaki Android background mein Priya ko band na kare.",
            isIgnoringBattery(c), button = "Open") { openSettings(c, Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, true) })

        // --- Granted automatically at install ---
        add(PermRow("Internet", "Gemini se jude rehne ke liye.", true, auto = true))
        add(PermRow("Background service", "Hamesha listening mode ke liye foreground service.", true, auto = true))
        add(PermRow("Microphone service", "Background mein mic chalane ki permission.", true, auto = true))
        add(PermRow("Wake lock", "Screen band hone par bhi connection chalu rakhna.", true, auto = true))
        add(PermRow("Start after reboot", "Phone restart hone par Priya dobara shuru ho.", true, auto = true))
        add(PermRow("Installed apps list", "Naam se app dhundkar kholne ke liye.", true, auto = true))
    }

    val done = rows.count { it.granted }
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Spacer(Modifier.height(8.dp))
            ScreenTitle("Permissions", "$done / ${rows.size} permissions on hain")
        }
        items(rows) { r ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (r.granted) Icons.Filled.CheckCircle else Icons.Filled.Warning,
                        contentDescription = null,
                        tint = if (r.granted) GREEN else AMBER,
                        modifier = Modifier.size(26.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(r.title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
                        Text(r.desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(Modifier.width(8.dp))
                    when {
                        r.auto -> Text("Auto", color = GREEN, style = MaterialTheme.typography.labelLarge)
                        r.granted -> Text("On", color = GREEN, style = MaterialTheme.typography.labelLarge)
                        else -> Button(onClick = r.onGrant) { Text(r.button) }
                    }
                }
            }
        }
        item {
            OutlinedButton(
                onClick = { openSettings(c, Settings.ACTION_APPLICATION_DETAILS_SETTINGS, true) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Android App settings kholo") }
            Spacer(Modifier.height(24.dp))
        }
    }
}

// ======================= MEMORY =======================

@Composable
fun MemoryScreen(app: AppCtx) {
    var refresh by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var newText by remember { mutableStateOf("") }
    var asPromise by remember { mutableStateOf(true) }
    var confirmClear by remember { mutableStateOf(false) }

    val used = remember(refresh) { app.memory.usedBytes() }
    val count = remember(refresh) { app.memory.count() }
    val list = remember(refresh, query) {
        if (query.isBlank()) app.memory.recent(200) else app.memory.search(query.trim(), 100)
    }
    val fmt = remember { SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()) }
    val usedMb = used / 1024f / 1024f
    val maxMb = MemoryStore.MAX_BYTES / 1024f / 1024f

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Spacer(Modifier.height(8.dp))
            ScreenTitle("Memory", "Aapke vaade aur baatein text mein save hoti hain")
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(14.dp)) {
                    Text(
                        String.format(Locale.US, "%.2f MB / %.0f MB use hua  |  %d entries", usedMb, maxMb, count),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { (used.toFloat() / MemoryStore.MAX_BYTES).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "30 MB bharne par sabse purani baatcheet hat jaati hai. Vaade sabse aakhir mein hatte hain.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(14.dp)) {
                    OutlinedTextField(
                        value = newText, onValueChange = { newText = it },
                        label = { Text("Kuch yaad rakhwao") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        FilterChip(selected = asPromise, onClick = { asPromise = true }, label = { Text("Vaada") })
                        Spacer(Modifier.width(8.dp))
                        FilterChip(selected = !asPromise, onClick = { asPromise = false }, label = { Text("Note") })
                        Spacer(Modifier.weight(1f))
                        Button(
                            enabled = newText.isNotBlank(),
                            onClick = {
                                app.memory.add(if (asPromise) "promise" else "note", newText)
                                newText = ""; refresh++
                            }
                        ) { Text("Save") }
                    }
                }
            }
        }
        item {
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                label = { Text("Memory mein dhundo") }, singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (list.isEmpty()) {
            item { Text("Abhi kuch save nahi hai.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        items(list, key = { it.id }) { m ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Row(Modifier.padding(start = 14.dp, top = 8.dp, bottom = 8.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        val tag = when (m.kind) { "promise" -> "VAADA"; "note" -> "NOTE"; "user" -> "AAP"; else -> "PRIYA" }
                        Text(
                            "$tag  |  ${fmt.format(Date(m.ts))}",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (m.kind == "promise") AMBER else MaterialTheme.colorScheme.primary
                        )
                        Text(m.text, color = MaterialTheme.colorScheme.onSurface)
                    }
                    IconButton(onClick = { app.memory.delete(m.id); refresh++ }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        item {
            TextButton(onClick = { confirmClear = true }) {
                Text("Poori memory saaf karo", color = MaterialTheme.colorScheme.error)
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Poori memory saaf karein?") },
            text = { Text("Saare vaade aur baatein hamesha ke liye hat jaayengi.") },
            confirmButton = {
                TextButton(onClick = { app.memory.clearAll(); PriyaBus.clearChat(); confirmClear = false; refresh++ }) { Text("Haan, saaf karo") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Nahi") } }
        )
    }
}

// ======================= GEMINI API =======================

@Composable
fun ApiScreen(app: AppCtx) {
    var key by remember { mutableStateOf(app.prefs.apiKey) }
    var show by remember { mutableStateOf(false) }
    var savedKey by remember { mutableStateOf(app.prefs.apiKey) }
    val dirty = key.trim() != savedKey

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        ScreenTitle("Gemini API", "Priya ki awaaz Gemini Live se chalti hai")
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(14.dp)) {
                OutlinedTextField(
                    value = key, onValueChange = { key = it },
                    label = { Text("Gemini API key") },
                    singleLine = true,
                    visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    trailingIcon = {
                        IconButton(onClick = { show = !show }) {
                            Icon(if (show) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, contentDescription = "Show")
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        enabled = key.isNotBlank() && dirty,
                        onClick = { app.prefs.apiKey = key; savedKey = key.trim() }
                    ) { Text("Save") }
                    Spacer(Modifier.width(12.dp))
                    if (savedKey.isNotBlank() && !dirty) {
                        Icon(Icons.Filled.CheckCircle, null, tint = GREEN, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Key save hai", color = GREEN)
                    }
                    Spacer(Modifier.weight(1f))
                    if (savedKey.isNotBlank()) {
                        TextButton(onClick = { app.prefs.apiKey = ""; key = ""; savedKey = "" }) { Text("Hatao") }
                    }
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        Text(
            "Model: ${app.prefs.model}\n\n" +
                "Free key aistudio.google.com/apikey se milti hai. Key sirf is phone mein encrypt hokar save hoti hai " +
                "aur sirf Google ke Gemini server par jaati hai.\n\n" +
                "Priya chalu hai to nayi key lagane ke liye usse ek baar band karke dobara shuru karo.",
            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

// ======================= SETTINGS =======================

@Composable
fun SettingsScreen(app: AppCtx) {
    val prefs = app.prefs
    var name by remember { mutableStateOf(prefs.userName) }
    var voice by remember { mutableStateOf(prefs.voice) }
    var model by remember { mutableStateOf(prefs.model) }
    var always by remember { mutableStateOf(prefs.alwaysListening) }
    var boot by remember { mutableStateOf(prefs.startOnBoot) }
    var style by remember { mutableStateOf(prefs.uiStyle) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        ScreenTitle("Settings")

        SectionCard("Aapka naam") {
            OutlinedTextField(
                value = name, onValueChange = { name = it; prefs.userName = it },
                label = { Text("Priya aapko kya bulaye?") }, singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }

        SectionCard("Hamesha sunna") {
            ToggleRow("Always listening (background)", "Priya hamesha sunti rahegi, notification ke saath", always) { on ->
                always = on; prefs.alwaysListening = on
                if (on && !PriyaBus.running.value) toggleListening(app)
                if (!on && PriyaBus.running.value) ListeningService.stop(app.context)
            }
            ToggleRow("Phone restart par shuru karo", "Android 14+ par kuch phones ise rok sakte hain", boot) { boot = it; prefs.startOnBoot = it }
        }

        SectionCard("Priya ki awaaz (female)") {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Prefs.FEMALE_VOICES.forEach { v ->
                    FilterChip(selected = voice == v, onClick = { voice = v; prefs.voice = v }, label = { Text(v) })
                }
            }
            Spacer(Modifier.height(6.dp))
            Text("Nayi awaaz agli baar Priya shuru hone par lagegi.", style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        SectionCard("Gemini Live model") {
            Prefs.MODELS.forEach { m ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = model == m, onClick = { model = m; prefs.model = m })
                    Column {
                        Text(m, color = MaterialTheme.colorScheme.onSurface)
                        val hint = when (m) {
                            "gemini-3.8-live" -> "Latest, default (recommended)"
                            "gemini-3.8-live-extended-thinking" -> "Zyada sochne wala, thoda slow"
                            else -> "Purana preview model"
                        }
                        Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        SectionCard("UI Style") {
            UiStyle.values().forEach { s ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = style == s, onClick = { style = s; app.setStyle(s) })
                    Column {
                        Text(s.label, color = MaterialTheme.colorScheme.onSurface)
                        val hint = when (s) {
                            UiStyle.ORB -> "Bada glowing orb, neeche menu bar"
                            UiStyle.CHAT -> "Chat bubbles, side drawer menu"
                            UiStyle.CARDS -> "Home par cards ka grid"
                        }
                        Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
private fun ToggleRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = MaterialTheme.colorScheme.onSurface)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

// ======================= ABOUT =======================

@Composable
fun AboutScreen(app: AppCtx) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        ScreenTitle("Priya AI", "Version 1.0")
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(14.dp)) {
                Text(
                    "Priya aapki female voice assistant hai.\n\n" +
                        "- Gemini Live (${app.prefs.model}) se live awaaz mein baat\n" +
                        "- Accessibility se apps kholna, screen padhna, tap, scroll, type\n" +
                        "- Background mein hamesha listening\n" +
                        "- 30 MB text memory: aapke vaade aur baatein yaad rakhti hai\n" +
                        "- Teen UI styles, Settings se badlo\n\n" +
                        "Priya sirf aapke bolne par kaam karti hai. Paisa, delete ya message bhejne jaise kaam se pehle woh puchhti hai.",
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}
