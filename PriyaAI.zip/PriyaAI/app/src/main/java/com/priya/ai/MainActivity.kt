package com.priya.ai

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.priya.ai.data.MemoryStore
import com.priya.ai.data.Prefs
import com.priya.ai.data.UiStyle
import com.priya.ai.live.PriyaBus
import com.priya.ai.service.ListeningService
import com.priya.ai.ui.AppCtx
import com.priya.ai.ui.ChatShell
import com.priya.ai.ui.CardsShell
import com.priya.ai.ui.MenuItem
import com.priya.ai.ui.OrbShell
import com.priya.ai.ui.PriyaTheme
import com.priya.ai.ui.hasPermission

class MainActivity : ComponentActivity() {

    private lateinit var prefs: Prefs
    private lateinit var memory: MemoryStore

    /** Bumped on resume and after permission results so permission states refresh. */
    private var tick by mutableIntStateOf(0)

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        prefs = Prefs(this)
        memory = MemoryStore.get(this)

        // Always-listening: start Priya when the app opens.
        if (prefs.alwaysListening && prefs.apiKey.isNotBlank() &&
            hasPermission(this, Manifest.permission.RECORD_AUDIO) && !PriyaBus.running.value
        ) {
            ListeningService.start(this)
        }

        setContent {
            var style by remember { mutableStateOf(prefs.uiStyle) }
            // null = Home. Style 3 shows the cards home; styles 1 and 2 treat null as the Talk page.
            var current by remember { mutableStateOf<MenuItem?>(null) }

            val app = AppCtx(
                context = this,
                prefs = prefs,
                memory = memory,
                tick = tick,
                requestPermission = { permissionLauncher.launch(it) },
                setStyle = { prefs.uiStyle = it; style = it },
                navigate = { current = it }
            )

            PriyaTheme(style) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    when (style) {
                        UiStyle.ORB -> OrbShell(app, current) { current = it }
                        UiStyle.CHAT -> ChatShell(app, current) { current = it }
                        UiStyle.CARDS -> CardsShell(app, current) { current = it }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        tick++
    }
}
