package com.priya.ai.live

import android.content.Context
import android.util.Base64
import com.priya.ai.data.MemoryStore
import com.priya.ai.data.Prefs
import com.priya.ai.service.PhoneTools
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

enum class LiveState { IDLE, CONNECTING, READY, ERROR }

interface LiveListener {
    fun onState(state: LiveState, detail: String = "")
    fun onAudio(pcm24k: ByteArray)
    fun onInterrupted()
    /** Called as transcript text arrives; final = true when the turn finished. */
    fun onTranscript(fromUser: Boolean, text: String, final: Boolean)
    fun onToolActivity(name: String)
}

/**
 * Raw WebSocket client for the Gemini Live API.
 * Input: 16 kHz 16-bit mono PCM. Output: 24 kHz 16-bit mono PCM.
 */
class GeminiLiveClient(
    private val context: Context,
    private val prefs: Prefs,
    private val memory: MemoryStore,
    private val listener: LiveListener
) {
    private val http = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    private val worker: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor()

    @Volatile private var ws: WebSocket? = null
    @Volatile private var wantConnected = false
    @Volatile private var ready = false
    @Volatile private var resumeHandle: String? = null
    private var retry = 0

    private val userBuf = StringBuilder()
    private val priyaBuf = StringBuilder()

    val isReady: Boolean get() = ready

    fun connect() {
        wantConnected = true
        openSocket()
    }

    fun disconnect() {
        wantConnected = false
        ready = false
        ws?.close(1000, "bye")
        ws = null
        flushTranscripts()
        listener.onState(LiveState.IDLE)
    }

    private fun openSocket() {
        val key = prefs.apiKey
        if (key.isBlank()) {
            listener.onState(LiveState.ERROR, "Gemini API key nahi daali. API screen mein key save karo.")
            return
        }
        ready = false
        listener.onState(LiveState.CONNECTING)
        val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta." +
            "GenerativeService.BidiGenerateContent?key=$key"
        ws = http.newWebSocket(Request.Builder().url(url).build(), socketListener)
    }

    // ---------- Sending ----------

    fun sendAudio(pcm16k: ByteArray) {
        if (!ready) return
        val msg = JSONObject().put(
            "realtimeInput",
            JSONObject().put(
                "audio",
                JSONObject()
                    .put("data", Base64.encodeToString(pcm16k, Base64.NO_WRAP))
                    .put("mimeType", "audio/pcm;rate=16000")
            )
        )
        ws?.send(msg.toString())
    }

    fun sendAudioStreamEnd() {
        if (!ready) return
        ws?.send(JSONObject().put("realtimeInput", JSONObject().put("audioStreamEnd", true)).toString())
    }

    fun sendText(text: String) {
        if (!ready) return
        ws?.send(JSONObject().put("realtimeInput", JSONObject().put("text", text)).toString())
        memory.add("user", text)
    }

    private fun sendSetup() {
        val model = prefs.model
        val gen = JSONObject()
            .put("responseModalities", JSONArray().put("AUDIO"))
            .put(
                "speechConfig",
                JSONObject().put(
                    "voiceConfig",
                    JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", prefs.voice))
                )
            )
        val setup = JSONObject()
            .put("model", "models/$model")
            .put("generationConfig", gen)
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt()))))
            .put("tools", PhoneTools.declarations(behaviorFor(model)))
            .put("inputAudioTranscription", JSONObject())
            .put("outputAudioTranscription", JSONObject())
            // Lets the session run longer than the 15 minute audio limit.
            .put("contextWindowCompression", JSONObject().put("slidingWindow", JSONObject()))
            .put(
                "sessionResumption",
                JSONObject().apply { resumeHandle?.let { put("handle", it) } }
            )
        ws?.send(JSONObject().put("setup", setup).toString())
    }

    /** Gemini 3.8 Live: BLOCKING by default here; Extended Thinking supports only NON_BLOCKING; 3.1 is sequential only. */
    private fun behaviorFor(model: String): String? = when {
        model.contains("extended-thinking") -> "NON_BLOCKING"
        model.contains("3.1") -> null
        else -> "BLOCKING"
    }

    private fun systemPrompt(): String {
        val name = prefs.userName.ifBlank { "user" }
        return """
            Tum "Priya" ho, ek dost jaisi, pyaari aur samajhdar female AI assistant. Tum $name ke phone mein rehti ho.
            - Hamesha ek ladki ki tarah bolo (feminine grammar), Hindi/Hinglish mein, jab tak user doosri bhasha na bole.
            - Jawab chhote aur natural rakho, jaise bolchaal mein hote hain.
            - Phone control ke liye tools use karo: open_app, read_screen, tap_text, tap_xy, type_text, scroll, press_button, call_contact.
            - Screen par kuch karne se pehle read_screen se dekho ki kya dikh raha hai.
            - Paisa bhejna, kuch delete karna, message bhejna jaise kaam karne se pehle user se pooch kar confirm karo.
            - Jab user koi vaada, kaam ya zaroori baat bataye, remember tool se use save karo (vaade ke liye kind=promise).
            - Purani baat poochhe to recall tool use karo.
            - Agar tool kahe ki Accessibility band hai, user ko batao ki Permissions screen se on kare.

            ${memory.contextForPrompt()}
        """.trimIndent()
    }

    // ---------- Receiving ----------

    private val socketListener = object : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
            retry = 0
            sendSetup()
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            if (webSocket === ws) handle(text)
        }

        // The Live API often delivers JSON inside binary frames.
        override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
            if (webSocket === ws) handle(bytes.utf8())
        }

        // Events from a socket we already replaced are ignored.
        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            if (webSocket !== ws) return
            ready = false
            if (wantConnected) scheduleReconnect("Connection band hua ($code) $reason")
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            if (webSocket !== ws) return
            ready = false
            val code = response?.code
            val why = when (code) {
                400, 401, 403 -> "API key ya model sahi nahi hai (HTTP $code)."
                else -> t.message ?: "Connection fail"
            }
            if (wantConnected) scheduleReconnect(why)
        }
    }

    private fun scheduleReconnect(reason: String) {
        retry++
        val delay = minOf(2L * retry, 15L)
        listener.onState(LiveState.ERROR, "$reason. $delay sec mein dobara try.")
        worker.schedule({
            if (wantConnected) {
                ws?.cancel()
                openSocket()
            }
        }, delay, TimeUnit.SECONDS)
    }

    private fun handle(raw: String) {
        val msg = try { JSONObject(raw) } catch (e: Exception) { return }

        if (msg.has("setupComplete")) {
            ready = true
            retry = 0
            listener.onState(LiveState.READY)
        }

        msg.optJSONObject("sessionResumptionUpdate")?.let {
            if (it.optBoolean("resumable") && it.optString("newHandle").isNotEmpty()) {
                resumeHandle = it.optString("newHandle")
            }
        }

        if (msg.has("goAway")) {
            // Server will drop us soon: reconnect now with the resume handle.
            worker.execute {
                if (wantConnected) {
                    val old = ws
                    openSocket()          // new socket first, resumes with the saved handle
                    old?.close(1000, "goAway")
                }
            }
        }

        msg.optJSONObject("serverContent")?.let { sc ->
            sc.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { parts ->
                for (i in 0 until parts.length()) {
                    val data = parts.getJSONObject(i).optJSONObject("inlineData")?.optString("data")
                    if (!data.isNullOrEmpty()) listener.onAudio(Base64.decode(data, Base64.DEFAULT))
                }
            }
            sc.optJSONObject("inputTranscription")?.optString("text")?.takeIf { it.isNotEmpty() }?.let {
                // Starting a new user utterance closes Priya's previous one.
                if (priyaBuf.isNotEmpty()) flushPriya()
                userBuf.append(it)
                listener.onTranscript(true, userBuf.toString(), false)
            }
            sc.optJSONObject("outputTranscription")?.optString("text")?.takeIf { it.isNotEmpty() }?.let {
                if (userBuf.isNotEmpty()) flushUser()
                priyaBuf.append(it)
                listener.onTranscript(false, priyaBuf.toString(), false)
            }
            if (sc.optBoolean("interrupted")) {
                listener.onInterrupted()
                flushPriya()
            }
            if (sc.optBoolean("turnComplete")) flushTranscripts()
        }

        msg.optJSONObject("toolCall")?.let { tc ->
            val calls = tc.optJSONArray("functionCalls") ?: return@let
            worker.execute { runToolCalls(calls) }
        }
    }

    private fun runToolCalls(calls: JSONArray) {
        val responses = JSONArray()
        for (i in 0 until calls.length()) {
            val fc = calls.getJSONObject(i)
            val name = fc.optString("name")
            listener.onToolActivity(name)
            val result = PhoneTools.execute(context, name, fc.optJSONObject("args") ?: JSONObject())
            responses.put(
                JSONObject()
                    .put("id", fc.optString("id"))
                    .put("name", name)
                    .put("response", JSONObject().put("result", result))
            )
        }
        ws?.send(JSONObject().put("toolResponse", JSONObject().put("functionResponses", responses)).toString())
    }

    private fun flushUser() {
        val t = userBuf.toString().trim()
        userBuf.setLength(0)
        if (t.isNotEmpty()) {
            memory.add("user", t)
            listener.onTranscript(true, t, true)
        }
    }

    private fun flushPriya() {
        val t = priyaBuf.toString().trim()
        priyaBuf.setLength(0)
        if (t.isNotEmpty()) {
            memory.add("priya", t)
            listener.onTranscript(false, t, true)
        }
    }

    private fun flushTranscripts() {
        flushUser()
        flushPriya()
    }
}
