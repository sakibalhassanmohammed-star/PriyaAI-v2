package com.priya.ai.service

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import com.priya.ai.data.Prefs

/** Restarts always-listening after the phone reboots (if the user turned it on). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = Prefs(context)
        val micOk = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (prefs.alwaysListening && prefs.startOnBoot && micOk && prefs.apiKey.isNotBlank()) {
            // Android 14+ blocks microphone foreground services from boot receivers,
            // so this may be refused on newer phones. The app then starts when the user opens it.
            runCatching { ListeningService.start(context) }
        }
    }
}
