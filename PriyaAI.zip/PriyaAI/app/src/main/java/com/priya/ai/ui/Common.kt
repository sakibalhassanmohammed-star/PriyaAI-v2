package com.priya.ai.ui

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.core.content.ContextCompat
import com.priya.ai.data.MemoryStore
import com.priya.ai.data.Prefs
import com.priya.ai.data.UiStyle
import com.priya.ai.live.PriyaBus
import com.priya.ai.service.ListeningService
import com.priya.ai.service.PriyaAccessibilityService

/** The menu. All three UI styles show exactly these options. */
enum class MenuItem(val title: String, val short: String, val subtitle: String, val icon: ImageVector) {
    TALK("Priya se baat", "Baat", "Voice chat shuru karo", Icons.Filled.Mic),
    MEMORY("Memory", "Memory", "Vaade aur yaadein (30 MB)", Icons.Filled.Memory),
    PERMISSIONS("Permissions", "Access", "Saari permissions yahan", Icons.Filled.Security),
    API("Gemini API", "API", "API key daalo aur save karo", Icons.Filled.Key),
    SETTINGS("Settings", "Settings", "Voice, model, UI style", Icons.Filled.Settings),
    ABOUT("About", "About", "Priya AI ke baare mein", Icons.Filled.Info)
}

/** Everything a screen needs. Re-created on resume so permission states refresh. */
class AppCtx(
    val context: Context,
    val prefs: Prefs,
    val memory: MemoryStore,
    val tick: Int,
    val requestPermission: (String) -> Unit,
    val setStyle: (UiStyle) -> Unit,
    val navigate: (MenuItem) -> Unit
)

fun hasPermission(c: Context, perm: String) =
    ContextCompat.checkSelfPermission(c, perm) == PackageManager.PERMISSION_GRANTED

fun isAccessibilityEnabled(c: Context): Boolean {
    val enabled = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        ?: return PriyaAccessibilityService.isRunning
    val me = ComponentName(c, PriyaAccessibilityService::class.java).flattenToString()
    return PriyaAccessibilityService.isRunning ||
        enabled.split(':').any { it.equals(me, true) || it.endsWith("PriyaAccessibilityService") }
}

fun isIgnoringBattery(c: Context): Boolean =
    (c.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(c.packageName)

fun openSettings(c: Context, action: String, withPackage: Boolean = false) {
    val i = Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    if (withPackage) i.data = Uri.parse("package:${c.packageName}")
    runCatching { c.startActivity(i) }
}

/** Start or stop Priya's background listening, asking for what is missing first. */
fun toggleListening(app: AppCtx) {
    val c = app.context
    if (PriyaBus.running.value) {
        ListeningService.stop(c)
        return
    }
    if (!hasPermission(c, Manifest.permission.RECORD_AUDIO)) {
        app.requestPermission(Manifest.permission.RECORD_AUDIO)
        return
    }
    if (app.prefs.apiKey.isBlank()) {
        app.navigate(MenuItem.API)
        return
    }
    ListeningService.start(c)
}
