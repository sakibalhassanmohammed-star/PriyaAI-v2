package com.priya.ai.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Gives Priya the ability to see the screen and operate the phone.
 * The user must enable it manually in Settings > Accessibility.
 */
class PriyaAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Priya only acts on demand; events are not stored.
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    // ---------- Actions ----------

    /** Launch an installed app by (part of) its name. */
    fun openApp(name: String): Boolean {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val wanted = name.trim().lowercase()
        val apps = pm.queryIntentActivities(launcher, 0)
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == wanted }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(wanted) }
            ?: apps.firstOrNull { wanted.contains(it.loadLabel(pm).toString().lowercase()) && it.loadLabel(pm).length > 2 }
            ?: return false
        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        startActivity(intent)
        return true
    }

    /** Text description of what is on screen, with tap coordinates for clickable items. */
    fun readScreen(maxChars: Int = 5000): String {
        val root = rootInActiveWindow ?: return "Screen padh nahi paya (koi window active nahi)."
        val sb = StringBuilder()
        sb.append("App: ").append(root.packageName ?: "?").append('\n')
        walk(root, sb, 0, maxChars)
        return sb.toString().take(maxChars)
    }

    private fun walk(node: AccessibilityNodeInfo?, sb: StringBuilder, depth: Int, max: Int) {
        if (node == null || sb.length >= max || depth > 40) return
        if (node.isVisibleToUser) {
            val label = node.text?.toString()?.takeIf { it.isNotBlank() }
                ?: node.contentDescription?.toString()?.takeIf { it.isNotBlank() }
                ?: node.hintText?.toString()?.takeIf { it.isNotBlank() }
            val flags = buildList {
                if (node.isClickable) add("clickable")
                if (node.isEditable) add("input")
                if (node.isScrollable) add("scrollable")
                if (node.isChecked) add("checked")
            }
            if (label != null || node.isEditable || node.isScrollable) {
                val r = Rect().also { node.getBoundsInScreen(it) }
                sb.append("- ")
                sb.append(label ?: "(no text)")
                if (flags.isNotEmpty()) sb.append(" [").append(flags.joinToString(",")).append(']')
                sb.append(" @").append(r.centerX()).append(',').append(r.centerY()).append('\n')
            }
        }
        for (i in 0 until node.childCount) walk(node.getChild(i), sb, depth + 1, max)
    }

    fun tapText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(text)
        if (nodes.isNullOrEmpty()) return false
        for (n in nodes) {
            var cur: AccessibilityNodeInfo? = n
            while (cur != null) {
                if (cur.isClickable && cur.isEnabled) return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                cur = cur.parent
            }
        }
        // No clickable parent: tap its center.
        val r = Rect().also { nodes[0].getBoundsInScreen(it) }
        return tapAt(r.centerX().toFloat(), r.centerY().toFloat())
    }

    fun tapAt(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 60)
        return dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val target = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: findEditable(root)
            ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun findEditable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isEditable) return node
        for (i in 0 until node.childCount) findEditable(node.getChild(i))?.let { return it }
        return null
    }

    fun scroll(direction: String): Boolean {
        val m = resources.displayMetrics
        val w = m.widthPixels.toFloat()
        val h = m.heightPixels.toFloat()
        val path = Path()
        when (direction.lowercase()) {
            "down" -> { path.moveTo(w / 2, h * 0.75f); path.lineTo(w / 2, h * 0.25f) }   // content moves up
            "up" -> { path.moveTo(w / 2, h * 0.25f); path.lineTo(w / 2, h * 0.75f) }
            "left" -> { path.moveTo(w * 0.2f, h / 2); path.lineTo(w * 0.8f, h / 2) }
            "right" -> { path.moveTo(w * 0.8f, h / 2); path.lineTo(w * 0.2f, h / 2) }
            else -> return false
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, 350)
        return dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    fun press(button: String): Boolean = when (button.lowercase()) {
        "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
        "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
        "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
        "quick_settings" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
        "lock" -> if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) else false
        else -> false
    }

    companion object {
        @Volatile var instance: PriyaAccessibilityService? = null
        val isRunning: Boolean get() = instance != null
    }
}
