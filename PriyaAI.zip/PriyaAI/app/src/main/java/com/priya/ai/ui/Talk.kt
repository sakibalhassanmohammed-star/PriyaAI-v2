package com.priya.ai.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.priya.ai.live.ChatLine
import com.priya.ai.live.LiveState
import com.priya.ai.live.PriyaBus
import com.priya.ai.service.ListeningService

fun statusLine(running: Boolean, state: LiveState, speaking: Boolean, detail: String): String = when {
    !running -> "Priya so rahi hai. Mic dabao"
    state == LiveState.CONNECTING -> "Connect ho rahi hoon..."
    state == LiveState.ERROR -> detail.ifBlank { "Kuch gadbad hui" }
    speaking -> "Priya bol rahi hai"
    else -> "Main sun rahi hoon"
}

// ======================= STYLE 1: ORB =======================

@Composable
fun OrbTalk(app: AppCtx) {
    val running by PriyaBus.running.collectAsState()
    val state by PriyaBus.state.collectAsState()
    val detail by PriyaBus.detail.collectAsState()
    val speaking by PriyaBus.speaking.collectAsState()
    val level by PriyaBus.level.collectAsState()
    val tool by PriyaBus.tool.collectAsState()
    val chat by PriyaBus.chat.collectAsState()

    val animLevel by animateFloatAsState(level.coerceIn(0f, 1f), tween(120), label = "level")
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue = 0.97f, targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulseValue"
    )
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val active = running && state == LiveState.READY

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.weight(1f))
        Box(Modifier.size(300.dp).alpha(if (running) 1f else 0.45f), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val base = size.minDimension / 2
                val r = base * (0.52f + 0.26f * animLevel) * (if (active) pulse else 0.95f)
                drawCircle(
                    Brush.radialGradient(listOf(primary.copy(alpha = 0.35f), Color.Transparent), radius = base),
                    radius = base
                )
                drawCircle(
                    Brush.radialGradient(listOf(secondary, primary, primary.copy(alpha = 0.25f)), radius = r),
                    radius = r
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            statusLine(running, state, speaking, detail),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center
        )
        val last = chat.lastOrNull()
        if (last != null) {
            Spacer(Modifier.height(10.dp))
            Text(
                (if (last.fromUser) "Aap: " else "Priya: ") + last.text,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                maxLines = 4
            )
        }
        if (tool.isNotBlank() && running) {
            Spacer(Modifier.height(6.dp))
            Text("Aakhri kaam: $tool", style = MaterialTheme.typography.labelSmall, color = primary)
        }
        Spacer(Modifier.weight(1f))
        FilledIconButton(onClick = { toggleListening(app) }, modifier = Modifier.size(72.dp)) {
            Icon(if (running) Icons.Filled.Stop else Icons.Filled.Mic, contentDescription = "Mic", modifier = Modifier.size(32.dp))
        }
        Spacer(Modifier.height(16.dp))
    }
}

// ======================= STYLE 2 (and Cards talk page): CHAT =======================

@Composable
fun ChatTalk(app: AppCtx) {
    val running by PriyaBus.running.collectAsState()
    val state by PriyaBus.state.collectAsState()
    val detail by PriyaBus.detail.collectAsState()
    val speaking by PriyaBus.speaking.collectAsState()
    val chat by PriyaBus.chat.collectAsState()
    val listState = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    val ready = running && state == LiveState.READY

    LaunchedEffect(chat.size, chat.lastOrNull()?.text) {
        if (chat.isNotEmpty()) listState.animateScrollToItem(chat.size - 1)
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(10.dp).clip(CircleShape)
                    .background(if (ready) Color(0xFF4CD964) else if (running) Color(0xFFFFB84D) else Color(0xFF8A8A8A))
            )
            Spacer(Modifier.size(8.dp))
            Text(
                statusLine(running, state, speaking, detail),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(1f)
            )
            FilledIconButton(onClick = { toggleListening(app) }) {
                Icon(if (running) Icons.Filled.Stop else Icons.Filled.Mic, contentDescription = "Mic")
            }
        }
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp),
            state = listState,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (chat.isEmpty()) {
                item {
                    Text(
                        "Mic dabake Priya se baat shuru karo. Aap yahan type bhi kar sakte ho.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
            items(chat) { line -> Bubble(line) }
        }
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                placeholder = { Text("Priya ko likho...") },
                modifier = Modifier.weight(1f), singleLine = true
            )
            IconButton(
                enabled = ready && input.isNotBlank(),
                onClick = { ListeningService.instance?.sendText(input.trim()); input = "" }
            ) { Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send") }
        }
    }
}

@Composable
private fun Bubble(line: ChatLine) {
    Box(Modifier.fillMaxWidth(), contentAlignment = if (line.fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
        Surface(
            shape = RoundedCornerShape(
                topStart = 18.dp, topEnd = 18.dp,
                bottomStart = if (line.fromUser) 18.dp else 4.dp,
                bottomEnd = if (line.fromUser) 4.dp else 18.dp
            ),
            color = if (line.fromUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.widthIn(max = 300.dp)
        ) {
            Text(
                line.text,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                color = if (line.fromUser) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

// ======================= STYLE 3: CARDS HOME =======================

@Composable
fun CardsHome(app: AppCtx, onOpen: (MenuItem) -> Unit) {
    val running by PriyaBus.running.collectAsState()
    val state by PriyaBus.state.collectAsState()
    val detail by PriyaBus.detail.collectAsState()
    val speaking by PriyaBus.speaking.collectAsState()

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Priya", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text(
                        statusLine(running, state, speaking, detail),
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
                Switch(checked = running, onCheckedChange = { toggleListening(app) })
            }
        }
        MenuItem.values().toList().chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                pair.forEach { m ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.weight(1f).height(130.dp).clip(RoundedCornerShape(12.dp)).clickable { onOpen(m) }
                    ) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
                            Icon(m.icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(30.dp))
                            Column {
                                Text(m.title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
                                Text(m.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                            }
                        }
                    }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}
