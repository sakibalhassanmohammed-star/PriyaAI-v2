package com.priya.ai.service

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import com.priya.ai.data.MemoryStore
import org.json.JSONArray
import org.json.JSONObject

/** The functions Gemini can call to control the phone and use memory. */
object PhoneTools {

    private fun param(type: String, desc: String) =
        JSONObject().put("type", type).put("description", desc)

    private fun fn(name: String, desc: String, props: JSONObject? = null, required: List<String> = emptyList(), behavior: String?): JSONObject {
        val o = JSONObject().put("name", name).put("description", desc)
        if (props != null) {
            o.put(
                "parameters",
                JSONObject().put("type", "OBJECT").put("properties", props)
                    .put("required", JSONArray(required))
            )
        }
        if (behavior != null) o.put("behavior", behavior)
        return o
    }

    /** [behavior] is BLOCKING / NON_BLOCKING, or null for models that only support sequential calls. */
    fun declarations(behavior: String?): JSONArray {
        val decls = JSONArray()
        decls.put(fn("open_app", "Phone mein koi app kholo, jaise WhatsApp, YouTube, Camera, Settings.",
            JSONObject().put("app_name", param("STRING", "App ka naam")), listOf("app_name"), behavior))
        decls.put(fn("read_screen", "Abhi screen par jo dikh raha hai use padho. Har item ke saath tap ke coordinates milte hain.",
            null, emptyList(), behavior))
        decls.put(fn("tap_text", "Screen par diye gaye text wale button ya item par tap karo.",
            JSONObject().put("text", param("STRING", "Button ya item ka text")), listOf("text"), behavior))
        decls.put(fn("tap_xy", "Screen ke coordinates par tap karo (read_screen se mile coordinates).",
            JSONObject().put("x", param("NUMBER", "X coordinate")).put("y", param("NUMBER", "Y coordinate")),
            listOf("x", "y"), behavior))
        decls.put(fn("type_text", "Jo text box active hai usme text likho.",
            JSONObject().put("text", param("STRING", "Likhne wala text")), listOf("text"), behavior))
        decls.put(fn("scroll", "Screen scroll karo.",
            JSONObject().put("direction", param("STRING", "up, down, left ya right")), listOf("direction"), behavior))
        decls.put(fn("press_button", "Phone ka system button dabao.",
            JSONObject().put("button", param("STRING", "back, home, recents, notifications, quick_settings ya lock")),
            listOf("button"), behavior))
        decls.put(fn("call_contact", "Kisi contact ko ya number par call karo.",
            JSONObject().put("name_or_number", param("STRING", "Contact ka naam ya phone number")),
            listOf("name_or_number"), behavior))
        decls.put(fn("remember", "User ki koi baat, vaada ya zaroori cheez hamesha ke liye yaad rakho.",
            JSONObject()
                .put("text", param("STRING", "Jo yaad rakhna hai, saaf shabdon mein"))
                .put("kind", param("STRING", "promise (vaada/commitment) ya note (aam yaad rakhne wali baat)")),
            listOf("text", "kind"), behavior))
        decls.put(fn("recall", "Purani yaad ki hui baatein dhundo.",
            JSONObject().put("query", param("STRING", "Kya dhundna hai")), listOf("query"), behavior))
        return JSONArray().put(JSONObject().put("functionDeclarations", decls))
    }

    fun execute(context: Context, name: String, args: JSONObject): JSONObject {
        val acc = PriyaAccessibilityService.instance
        fun ok(msg: String) = JSONObject().put("ok", true).put("message", msg)
        fun fail(msg: String) = JSONObject().put("ok", false).put("error", msg)
        val needAcc = "Accessibility service band hai. User se bolo ki Priya AI ke Permissions mein Accessibility on kare."

        return try {
            when (name) {
                "open_app" -> {
                    if (acc == null) fail(needAcc)
                    else if (acc.openApp(args.optString("app_name"))) ok("App khul gaya.")
                    else fail("Is naam ka app nahi mila.")
                }
                "read_screen" -> if (acc == null) fail(needAcc) else ok(acc.readScreen())
                "tap_text" -> if (acc == null) fail(needAcc) else
                    if (acc.tapText(args.optString("text"))) ok("Tap ho gaya.") else fail("Ye text screen par nahi mila.")
                "tap_xy" -> if (acc == null) fail(needAcc) else
                    if (acc.tapAt(args.optDouble("x").toFloat(), args.optDouble("y").toFloat())) ok("Tap ho gaya.") else fail("Tap fail hua.")
                "type_text" -> if (acc == null) fail(needAcc) else
                    if (acc.typeText(args.optString("text"))) ok("Text likh diya.") else fail("Koi text box nahi mila.")
                "scroll" -> if (acc == null) fail(needAcc) else
                    if (acc.scroll(args.optString("direction"))) ok("Scroll ho gaya.") else fail("Direction galat hai.")
                "press_button" -> if (acc == null) fail(needAcc) else
                    if (acc.press(args.optString("button"))) ok("Ho gaya.") else fail("Button galat hai.")
                "call_contact" -> callContact(context, args.optString("name_or_number"))
                "remember" -> {
                    val kind = if (args.optString("kind") == "promise") "promise" else "note"
                    MemoryStore.get(context).add(kind, args.optString("text"))
                    ok("Yaad rakh liya.")
                }
                "recall" -> {
                    val hits = MemoryStore.get(context).search(args.optString("query"), 15)
                    if (hits.isEmpty()) ok("Kuch nahi mila.")
                    else ok(hits.joinToString("\n") { "[${it.kind}] ${it.text}" })
                }
                else -> fail("Unknown function: $name")
            }
        } catch (e: Exception) {
            fail(e.message ?: "Error")
        }
    }

    private fun callContact(context: Context, query: String): JSONObject {
        var number = query.filter { it.isDigit() || it == '+' }
        if (number.length < 5) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
                return JSONObject().put("ok", false).put("error", "Contacts permission nahi di gayi.")
            number = ""
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$query%"), null
            )?.use { c -> if (c.moveToFirst()) number = c.getString(0) ?: "" }
            if (number.isEmpty()) return JSONObject().put("ok", false).put("error", "Contact nahi mila.")
        }
        val canCall = ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        val intent = Intent(if (canCall) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number)))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        (PriyaAccessibilityService.instance ?: context).startActivity(intent)
        return JSONObject().put("ok", true).put("message", if (canCall) "Call laga raha hoon." else "Dialer khol diya.")
    }
}
