package com.priya.ai.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.priya.ai.data.UiStyle

/** Each of the three UI styles has its own colour palette. */
@Composable
fun PriyaTheme(style: UiStyle, content: @Composable () -> Unit) {
    val scheme = when (style) {
        UiStyle.ORB -> darkColorScheme(
            primary = Color(0xFFB388FF), onPrimary = Color(0xFF1A0B3D),
            secondary = Color(0xFFFF6FB5), onSecondary = Color(0xFF3D0B24),
            background = Color(0xFF07060F), onBackground = Color(0xFFEDE9FF),
            surface = Color(0xFF14122A), onSurface = Color(0xFFEDE9FF),
            surfaceVariant = Color(0xFF1F1B3D), onSurfaceVariant = Color(0xFFC9C2EE),
            primaryContainer = Color(0xFF3A2A73), onPrimaryContainer = Color(0xFFE6DDFF),
            error = Color(0xFFFF6B6B)
        )
        UiStyle.CHAT -> darkColorScheme(
            primary = Color(0xFF4DD0C4), onPrimary = Color(0xFF00201D),
            secondary = Color(0xFF9AD7FF), onSecondary = Color(0xFF00263D),
            background = Color(0xFF0E1417), onBackground = Color(0xFFE2EEF0),
            surface = Color(0xFF1A252A), onSurface = Color(0xFFE2EEF0),
            surfaceVariant = Color(0xFF22323A), onSurfaceVariant = Color(0xFFB7CBD0),
            primaryContainer = Color(0xFF0F4F4A), onPrimaryContainer = Color(0xFFBFF5EF),
            error = Color(0xFFFF6B6B)
        )
        UiStyle.CARDS -> darkColorScheme(
            primary = Color(0xFFFFC46B), onPrimary = Color(0xFF3B2600),
            secondary = Color(0xFF7EA6FF), onSecondary = Color(0xFF001A44),
            background = Color(0xFF0F1626), onBackground = Color(0xFFEAF0FF),
            surface = Color(0xFF1B2540), onSurface = Color(0xFFEAF0FF),
            surfaceVariant = Color(0xFF25315A), onSurfaceVariant = Color(0xFFC0CBEA),
            primaryContainer = Color(0xFF5C4210), onPrimaryContainer = Color(0xFFFFE3B3),
            error = Color(0xFFFF6B6B)
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
