package com.priya.ai.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class MemoryItem(val id: Long, val ts: Long, val kind: String, val text: String)

/**
 * Text-only memory with a hard 30 MB cap.
 * kind: "user" and "priya" (conversation lines), "promise" (vaade / commitments), "note".
 * When the cap is hit the oldest conversation lines go first; promises are removed last.
 */
class MemoryStore private constructor(context: Context) :
    SQLiteOpenHelper(context.applicationContext, "priya_memory.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE memories(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, " +
                "kind TEXT NOT NULL, text TEXT NOT NULL)"
        )
        db.execSQL("CREATE INDEX idx_kind_ts ON memories(kind, ts)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    @Synchronized
    fun add(kind: String, text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        val cv = ContentValues().apply {
            put("ts", System.currentTimeMillis())
            put("kind", kind)
            put("text", clean)
        }
        writableDatabase.insert("memories", null, cv)
        enforceLimit()
    }

    @Synchronized
    fun usedBytes(): Long {
        readableDatabase.rawQuery("SELECT COALESCE(SUM(LENGTH(text) + LENGTH(kind) + 24), 0) FROM memories", null)
            .use { c -> return if (c.moveToFirst()) c.getLong(0) else 0L }
    }

    @Synchronized
    fun count(): Int {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM memories", null)
            .use { c -> return if (c.moveToFirst()) c.getInt(0) else 0 }
    }

    @Synchronized
    fun recent(limit: Int = 200, kind: String? = null): List<MemoryItem> {
        val sql = if (kind == null)
            "SELECT id, ts, kind, text FROM memories ORDER BY id DESC LIMIT ?"
        else
            "SELECT id, ts, kind, text FROM memories WHERE kind = ? ORDER BY id DESC LIMIT ?"
        val args = if (kind == null) arrayOf(limit.toString()) else arrayOf(kind, limit.toString())
        val out = ArrayList<MemoryItem>()
        readableDatabase.rawQuery(sql, args).use { c ->
            while (c.moveToNext()) out.add(MemoryItem(c.getLong(0), c.getLong(1), c.getString(2), c.getString(3)))
        }
        return out
    }

    @Synchronized
    fun search(query: String, limit: Int = 20): List<MemoryItem> {
        val out = ArrayList<MemoryItem>()
        readableDatabase.rawQuery(
            "SELECT id, ts, kind, text FROM memories WHERE text LIKE ? ORDER BY id DESC LIMIT ?",
            arrayOf("%$query%", limit.toString())
        ).use { c ->
            while (c.moveToNext()) out.add(MemoryItem(c.getLong(0), c.getLong(1), c.getString(2), c.getString(3)))
        }
        return out
    }

    @Synchronized
    fun delete(id: Long) {
        writableDatabase.delete("memories", "id = ?", arrayOf(id.toString()))
    }

    @Synchronized
    fun clearAll() {
        writableDatabase.delete("memories", null, null)
    }

    /** Text block that is added to Priya's instructions at the start of every session. */
    @Synchronized
    fun contextForPrompt(maxChars: Int = 8000): String {
        val sb = StringBuilder()
        val promises = recent(60, "promise").reversed()
        if (promises.isNotEmpty()) {
            sb.append("User ke vaade / zaroori baatein:\n")
            promises.forEach { sb.append("- ").append(it.text).append('\n') }
        }
        val notes = recent(30, "note").reversed()
        if (notes.isNotEmpty()) {
            sb.append("\nYaad rakhne wali baatein:\n")
            notes.forEach { sb.append("- ").append(it.text).append('\n') }
        }
        val chat = recent(30).filter { it.kind == "user" || it.kind == "priya" }.reversed()
        if (chat.isNotEmpty()) {
            sb.append("\nPichli baatcheet:\n")
            chat.forEach { sb.append(if (it.kind == "user") "User: " else "Priya: ").append(it.text).append('\n') }
        }
        return if (sb.length > maxChars) sb.substring(sb.length - maxChars) else sb.toString()
    }

    private fun enforceLimit() {
        if (usedBytes() <= MAX_BYTES) return
        val db = writableDatabase
        // Pass 1: drop old conversation lines until we are at 90% of the cap.
        while (usedBytes() > MAX_BYTES * 0.9) {
            val n = db.delete(
                "memories",
                "id IN (SELECT id FROM memories WHERE kind IN ('user','priya') ORDER BY id ASC LIMIT 500)",
                null
            )
            if (n == 0) break
        }
        // Pass 2: still too big, drop the oldest notes and promises.
        while (usedBytes() > MAX_BYTES * 0.9) {
            val n = db.delete(
                "memories",
                "id IN (SELECT id FROM memories ORDER BY id ASC LIMIT 200)",
                null
            )
            if (n == 0) break
        }
    }

    companion object {
        const val MAX_BYTES = 30L * 1024 * 1024
        @Volatile private var instance: MemoryStore? = null
        fun get(context: Context): MemoryStore =
            instance ?: synchronized(this) {
                instance ?: MemoryStore(context).also { instance = it }
            }
    }
}
