# Priya AI (Android)

Female voice assistant jo Gemini Live (`gemini-3.8-live`) se baat karti hai, phone control kar sakti hai aur aapke vaade 30 MB text memory mein yaad rakhti hai.

## Build karna

1. Android Studio (Koala ya naya) kholo, **Open** se `PriyaAI` folder chuno.
2. Gradle sync hone do (internet chahiye). Gradle 8.7 apne aap download hoga.
3. Phone USB debugging ke saath jodo aur **Run** dabao. Ya **Build > Build APK(s)**.

> Ye project abhi compile karke test nahi kiya gaya (yahan Android SDK nahi tha). Pehli build mein chhoti compile errors aa sakti hain, error ka text bhej dena, main theek kar dunga.

## Pehli baar setup

1. **Gemini API** menu: key daalo (aistudio.google.com/apikey se free) aur Save dabao.
2. **Permissions** menu: Microphone, Notifications allow karo.
3. **Accessibility** wali row par Open dabao aur Settings mein "Priya AI" on karo.
   - Sideload (APK se install) kiya hai to Android 13+ par pehle: Settings > Apps > Priya AI > teen dots (⋮) > **Allow restricted settings**. Uske baad Accessibility on hoga.
4. Battery optimization off kar do, warna Android background mein Priya ko band kar sakta hai.
5. Mic button dabao. Priya "sun rahi hai" dikhaye to bolna shuru karo.

## Features

| Feature | Kahan hai |
|---|---|
| Female live voice (Kore, Aoede, Leda, Zephyr, Despina, Sulafat) | Settings |
| Model: `gemini-3.8-live` (default), `3.8-live-extended-thinking`, `3.1-flash-live-preview` | Settings |
| Phone control: app kholna, screen padhna, tap, scroll, type, back/home, call | Accessibility service |
| Hamesha listening (foreground service + notification) | Settings > Always listening |
| 30 MB text memory (vaade, notes, baatcheet) | Memory menu |
| Teen UI styles, har ek mein poora menu | Settings > UI Style |
| Saari permissions ek jagah | Permissions menu |
| Gemini API key (encrypted save) | Gemini API menu |

## Teen UI styles

- **Style 1 Orb:** bada glowing orb, neeche menu bar.
- **Style 2 Chat:** chat bubbles, side drawer menu.
- **Style 3 Cards:** home par cards ka grid.

Teeno mein menu ke options same hain: Priya se baat, Memory, Permissions, Gemini API, Settings, About.

## Memory kaise kaam karti hai

- Har baatcheet ka text aur jo vaade Priya "remember" tool se save karti hai, `priya_memory.db` mein jaate hain.
- Limit 30 MB. Bharne par sabse purani baatcheet hat jaati hai, vaade sabse aakhir mein.
- Har session ke shuru mein vaade, notes aur pichli baatcheet Priya ko batayi jaati hain.

## Dhyan dene wali baatein

- **Battery aur data:** Awaaz tabhi Gemini ko bheji jaati hai jab koi bol raha ho (local voice gate), phir bhi hamesha listening mein battery aur data kharch hota hai. Gemini API ki billing aapki key par lagti hai.
- **Android 14+:** Phone restart par microphone service khud shuru karne ko Android rok sakta hai. Us case mein app kholne par Priya shuru hoti hai.
- **Play Store:** Accessibility se phone control Google Play ki policy mein restricted hai. Ye app personal/sideload use ke liye hai.
- **Echo:** Priya ki awaaz mic mein wapas na jaaye isliye echo cancellation use hota hai. Speaker bahut tez ho to earphones lagao.
- **Safety:** Priya paisa bhejne, delete karne ya message bhejne se pehle aapse puchhne ke liye instruct ki gayi hai (`GeminiLiveClient.systemPrompt`).

## Code ka naksha

```
app/src/main/java/com/priya/ai/
  MainActivity.kt                 entry, style switch
  data/Prefs.kt                   settings, encrypted API key
  data/MemoryStore.kt             30 MB SQLite text memory
  live/GeminiLiveClient.kt        Gemini Live WebSocket (setup, audio, tool calls)
  live/PriyaBus.kt                UI ke liye shared state
  service/ListeningService.kt     background mic + speaker
  service/PriyaAccessibilityService.kt   screen padhna, tap, scroll, apps kholna
  service/PhoneTools.kt           Gemini ke tools ki list aur unka code
  service/BootReceiver.kt         restart ke baad shuru
  ui/                             teen shells, screens, theme
```

Design badalna ho (aapke screenshots ke hisaab se): `ui/Theme.kt` mein colours aur `ui/Shells.kt` / `ui/Talk.kt` mein layouts hain.
